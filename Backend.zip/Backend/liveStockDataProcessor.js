// import { NseIndia } from  "stock-nse-india";
// const  nseIndia = new  NseIndia()



// const processDataChange = async ()=>{
//    const symbols= await nseIndia.getAllStockSymbols();
//    console.log(symbols);   
// }   


// export default processDataChange;